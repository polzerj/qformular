dotnet QFormular.dll $a $b $c
alias run='. ~/Schreibtisch/QFormular/bin/Debug/netcoreapp2.1/run.sh'

